import java.util.Arrays;

public class Parametre {
    public static void main(String[] args) {
        int number = 10; // primitivny typ
        String str = "abcd"; // referencny typ
        int[] arr = {10, 20, 30}; // referencny typ
        StringBuilder builder = new StringBuilder("prvy"); // referencny typ

        met1(number);
        System.out.println("main: number = " + number);

        met2(str);
        System.out.println("main: str = " + str);

        met3(arr);
        System.out.println("main: arr = " + Arrays.toString(arr));

        met4(builder);
        System.out.println("main: builder = " + builder.toString());
    }

    private static void met1(int number) { // kopia hodnoty
        ++ number;
        System.out.println("met1: number = " + number);
    }

    private static void met2(String text) { // kopia referncie
        text = "pocitac"; // text = new String("pocitac");
        System.out.println("met2: text = " + text);
    }

    private static void met3(int[] array) { // kopia referncie na pole
        array[1] = 200;
        System.out.println("met3: array = " + Arrays.toString(array));
    }

    private static void met4(StringBuilder b) { // kopia referencie
        b.append(" druhy");
        System.out.println("met4: b = " + b.toString());
    }
}
