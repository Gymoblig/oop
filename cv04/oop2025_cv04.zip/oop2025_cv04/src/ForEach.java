public class ForEach {
    public static void main(String[] args) {
        int[] data = {10, 20, 30, 40};

        for (int i = 0; i < data.length; ++ i) { // tradicny for
            System.out.print(i + ": " + data[i] + ", "); // System.out.format("%d: %d, ", i, data[i]);
        }
        System.out.println();

        for (int element: data) { // "for each"
            System.out.format("%d, ", element);
        }
        System.out.println();
    }
}
