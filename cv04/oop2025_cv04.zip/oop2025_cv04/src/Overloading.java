public class Overloading {
    public static void main(String[] args) {
        print(10);
        print("oop");
    }

    private static void print(int integer) {
        System.out.println("integer: " + integer);
    }

    private static void print(String text) {
        System.out.println("text: " + text);
    }
}
