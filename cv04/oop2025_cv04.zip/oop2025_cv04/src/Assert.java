// Nastavenie
//   - na prikazovom riadku pouzit -enableassertions alebo -ea
//   - treba nastavit pretoze 'assert' nebol v prvej verzii javy.
//     Nebol klucovym slovom a preto 'assert' mohlo byt pouzite napriklad pre nazov funkcie
// Nastavenie v IntelliJ
//   - https://se-education.org/guides/tutorials/intellijUsefulSettings.html
// Pouzitie:
//  - pre chyby, ktore by nemali nikdy nastat
//  - neosetrovat vstup od pouzivatela a podobne (do verejnych metod) ..... assert moze byt vypnuty

public class Assert {
    public static void main(String[] args) {
        System.out.println(averageSpeed(10, 10, 20, 20));
        System.out.println(averageSpeed(20, 20, 25, 30));
        System.out.println(averageSpeed(5, 10, 5, 20));
    }

    private static double averageSpeed(int startTime, int startPosition, int endTime, int endPosition) {
        assert endTime > startTime;
        assert endTime > startTime : "zaciatocny cas musi byt mensi ako koncovy";

        return (double)(endPosition - startPosition) / (double) (endTime - startTime);
    }
}
