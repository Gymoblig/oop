public class BreakAndContinue {
    public static void main(String[] args) {
        String[] words = {
                "ABCD",
                "EfGH",
                "ijkl",
                "MNOP"
        };

        boolean contains = containsAll(words, new char[] {'A', 'N'});
        System.out.println("containsAll: " + contains);

        System.out.println("upper case words:");
        printUppercaseWords(words);

    }

    private static boolean containsAll(String[] text, char[] letters) {
        int coutner = 0;
        for (char searchedLetter: letters) {
            search:
            for (String word: text) {
                for (char type: word.toCharArray()) {
                    if (type == searchedLetter) {
                        ++ coutner;
                        break search;
                    }
                }
            }
        }
        return coutner == letters.length;
    }

    private static void printUppercaseWords(String[] text) {
        search:
        for (String word: text) {
            for (char letter: word.toCharArray()) {
                if (! Character.isUpperCase(letter)) {
                    continue search;
                }
            }
            System.out.println(word);
        }
    }
}
