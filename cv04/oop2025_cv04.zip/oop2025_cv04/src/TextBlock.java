public class TextBlock {
    public static void main(String[] args) {
        String code = """
                int main() {
                    int a = 10;
                    int b = 20;
                    return 0;
                }
                """;
        System.out.println(code);
    }
}
