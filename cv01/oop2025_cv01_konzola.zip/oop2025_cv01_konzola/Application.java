import logger.Logger;

public class Application {
    public static void main(String[] args) {
        System.out.println("aplikacia spustena");
        System.out.println();

        printHeader("Lekcia c. 1");
        System.out.println("obsah prvej lekcie");
        System.out.println();

        printHeader("Lekcia c. 2");
        System.out.println("obsah druhej lekcie");
        System.out.println();

        Drawer.drawRectangle();
        System.out.println();
        Drawer.drawTriangle();

        Logger.debug("ladiaca sprava");
        Logger.error("chybava sprava");
    }

    private static void printHeader(String header) {
        System.out.println(header);
        
        int headerLength = header.length();
        for (int i = 0; i < headerLength; ++ i) {
            System.out.print("-");
        }
        System.out.println();
        System.out.println();
    }
}
