public class Drawer {
    public static void drawRectangle() {
        System.err.println("**********");
        System.err.println("*        *");
        System.err.println("*        *");
        System.err.println("*        *");
        System.err.println("**********");
    }

    public static void drawTriangle() {
        System.out.println("    *");
        System.out.println("   * *");
        System.out.println("  *   *");
        System.out.println(" *     *");
        System.out.println("*********");
    }

    public static void main(String[] args) {
        System.out.println("drawer main");
    }
}
