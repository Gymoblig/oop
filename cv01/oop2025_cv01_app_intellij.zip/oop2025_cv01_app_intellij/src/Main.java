import org.tinylog.Logger;

public class Main {
    public static void main(String[] args) {
        System.out.println("prvy riadok");
        System.out.print("Neodriadkovany");
        System.out.println("Odriadkovany");

        Logger.info("informacny vypis");
        Logger.debug("debugovaci vypis");
        Logger.error("chybovy vypis");
    }
}
