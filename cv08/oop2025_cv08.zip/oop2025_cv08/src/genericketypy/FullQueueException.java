package genericketypy;

public class FullQueueException extends QueueException {
    // TODO
}
