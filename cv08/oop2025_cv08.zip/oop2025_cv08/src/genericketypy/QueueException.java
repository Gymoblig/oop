package genericketypy;

public class QueueException extends Exception {
    // TODO
}
