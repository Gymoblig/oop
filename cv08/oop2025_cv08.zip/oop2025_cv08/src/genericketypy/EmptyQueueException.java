package genericketypy;

public class EmptyQueueException extends QueueException {
    // TODO
}
