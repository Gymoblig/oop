package vnorenetypy;

import javax.swing.*;

public class VnoreneTypyAplikacia {
    public static void main(String[] args) {
        WindowStarter starter = new WindowStarter();
        SwingUtilities.invokeLater(starter);
    }
}
