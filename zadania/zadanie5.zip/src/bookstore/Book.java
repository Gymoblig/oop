package bookstore;


public class Book implements Comparable<Book> {


    /**
     * Calculate the checksum of the ISBN.
     * ISBN may be ISBN-10 or ISBN-13.
     * ISBN is represented as a string without hyphens.
     * If the input contains any hyphens, spaces, or other characters which are not digits or the character X,
     * the potentialISBN check returns false.
     * Only check the checksum, you may disregard any other information the ISBN contains (e.g. country code).
     * @param potentialISBN the string the check. It must only contain characters 0-9, X.
     * @return true if the potentialISBN is a valid ISBN, false otherwise
     */
    public static boolean isISBNValid(String potentialISBN) {
        // todo implement
    }

    /**
     * Initialize the book.
     * @param ISBN a valid ISBN
     * @param title a non-null, non-empty title of the book
     * @param author a non-null, non-empty full name of the author
     * @param year a non-negative year of publication
     * @throws IllegalArgumentException if any of the parameters are invalid
     */
    public Book(String ISBN, String title, String author, int year) {
        // todo implement
    }


    public String getISBN() {
        // todo implement
    }

    public String getTitle() {
        // todo implement
    }

    public String getAuthor() {
        // todo implement
    }

    public int getYear() {
        // todo implement
    }

    @Override
    public boolean equals(Object o) {
        // todo implement
    }

    @Override
    public int hashCode() {
        // todo implement
    }

    @Override
    public int compareTo(Book o) {
        // todo implement
    }
}