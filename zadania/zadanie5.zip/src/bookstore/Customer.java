package bookstore;

import java.util.Set;

public class Customer {

    /**
     * Initialize a customer.
     * @param name the non-null, non-empty name of the customer
     * @throws IllegalArgumentException if the name is invalid
     */
    public Customer(String name) {
        // todo implement
    }

    /**
     * get the name.
     * @return the name of the customer
     */
    public String getName() {
        // todo implement
    }

    /**
     * Get the books the customer owns.
     * @return the set of customer's books.
     */
    public Set<Book> getOwnedBooks() {
        // todo implement
    }

    /**
     * Attempt to purchase all books from the specified store which are not yet owned.
     * @param bs the bookstore to purchase from
     * @throws IllegalArgumentException if the bookstore is null
     */
    public void purchaseNewBooks(BookStore bs) {
        // todo implement
    }
}
