package bookstore;

public class NotInInventoryException extends RuntimeException {
    public NotInInventoryException(Book book) {
        // todo implement
    }
}
