package manipulation;

public enum RotationDirection {
    LEFT, RIGHT
}
