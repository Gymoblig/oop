public class RectangleTester {
    public static void main(String[] args) {
        Rectangle.print(10, 5);
        Rectangle.print(0, 0);
        Rectangle.print(1, 5);
        Rectangle.print(2, 5);
        Rectangle.print(10, 1);
        Rectangle.print(10, 2);
    }
}