# obdlznik

## format suboru

markdown

## o projekte

Program vykresluje obdlzniky do textove konzoly

```java
// volanie
Rectangle.print(10, 5);
```

oprava vykonana este raz po cviku
